import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="usf_helpers",
    version="0.1.0",
    author="Steve Griswold",
    author_email="steve.griswold@usfoods.com",
    description="US Foods Helpers for I&A.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://bitbucket.usfood.com/projects/IAD/repos/ds-knowledge/",
    packages=setuptools.find_packages(include=('*.py')),
    install_requires=[
        'boto3==1.9.79',
        'numpy==1.18.2',
        'openpyxl==3.0.3',
        'pyyaml==5.1.2',
        'snowflake==0.0.3',
        'snowflake-connector-python==2.1.2',
        'pandas==0.25.3'
        ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
