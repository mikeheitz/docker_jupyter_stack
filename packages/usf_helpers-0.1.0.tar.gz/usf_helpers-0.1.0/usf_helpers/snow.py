import os
import datetime as dt
from string import Template
import snowflake.connector
import pandas as pd
import numpy as np
from usf_helpers import config


def parse_data(data, max_length=16000):
    """Format the data into a string list fomat.
    parse_data will allow uploads over the max_length.
    When Possible use S3 file and Insert CSV for large lists.
    
    data = [ f"('{r[0]}', '{r[1]}', {r[2]}, ... )" for r in df.values]

    :param data: data to insert into Snowflake Table.
    :type data: list(list(string))
    :param max_length: Batchsize, defaults to 16000
    :type max_length: int, optional
    :return: Packets are formated string to insert into SQL statement.
    :rtype: list(string)
    """

    packets = []
    if len(data) > max_length:
        # parse
        batches = np.arange(0, len(data), max_length-1)
        for idx, b in enumerate(batches):
            end = (idx+1)*max_length-1
            if end > len(data):
                end = len(data)+1
            data_values = ""
            for r in data[b:end]:
                if data_values == "":
                    data_values += r
                else:
                    data_values += ",\n" + r
            packets.append(data_values)
    else:
        # full
        data_values = ""
        for r in data:
            if data_values == "":
                data_values += r
            else:
                data_values += ",\n" + r
        packets = data_values
    return packets


class SnowflakeConnector:
    """
    DOCSTRING:  Class to Manage Content of Snowflake Connection.
    """

    def __init__(self,
                 user_name=None,
                 pwd=None,
                 account='usfoods',
                 database='GOLD',
                 warehouse='USER_ADHOC',
                 schema='XDMADM',
                 role='BUSINESS_ANALYTICS'):
        """Connect to Snowflake.

        :param user_name: Snowflake User Name
        :type user_name: str
        :param pwd: Snowflake Password
        :type pwd: str
        :param account: Snowflake Account, defaults to 'usfoods'
        :type account: str, optional
        :param database: Snowflake Database, defaults to 'GOLD'
        :type database: str, optional
        :param warehouse: Snowflake Warehouse, defaults to 'USER_ADHOC'
        :type warehouse: str, optional
        :param schema: Snowflake Schema, defaults to 'XDMADM'
        :type schema: str, optional
        :param role: Snowflake Role, defaults to 'BUSINESS_ANALYTICS'
        :type role: str, optional
        """

        if user_name is None:
            try:
                user_name = os.environ['SNOWFLAKE_USER']
            except KeyError:
                print("No os environment variable called:  ['SNOWFLAKE_USER']")
        if pwd is None:
            try:
                pwd = os.environ['SNOWFLAKE_PASSWORD']
            except KeyError:
                print("No os environment variable called:  ['SNOWFLAKE_PASSWORD']")

        self.conn = None
        self.cursor = False
        self.closed = True
        self.user_name = user_name
        self.pwd = pwd
        self.account = account
        self._database = database
        self.warehouse = warehouse
        self._schema = schema
        self.role = role

    @classmethod
    def get_snow(cls, env, cfg, aws_region = 'us-west-2'):
        """Get a snowflake connector by passing the IAConfig Object.
        
        :param env: default, local, dev, qa, prod
        :type env: str
        :param cfg: IAConfigfile if none uses local os environ
        :type cfg: usf_helpers.config.IAConfig()
        :return: SnowConnector for config settings.
        :rtype: snow.SnowConnector()
        """

        if env == 'local':
            assert os.environ['SNOWFLAKE_USER']
            usr = os.environ['SNOWFLAKE_USER']
            assert os.environ['SNOWFLAKE_PASSWORD'] 
            pwd = os.environ['SNOWFLAKE_PASSWORD']
        elif env == 'prod':
            # USF Server use Service Account /app/config/config.yml
            usr_key = cfg.get('uid')
            usr = config.decrypt_value(usr_key, aws_region)
            pwd_key = cfg.get('pwd')
            pwd = config.decrypt_value(pwd_key, aws_region)
        else:
            # Keys must be in config/config.yml
            # these key names are auto decrypted by config.
            usr = cfg.get('snflk_uid', aws_region)
            pwd = cfg.get('snflk_pwd', aws_region)
            
        # set profile by data warehouse
        db_profile = cfg.get('datawarehouse')
        conn = cls(
            user_name=usr,
            pwd=pwd,
            account=db_profile['account'],
            database=db_profile['db'],
            warehouse=db_profile['warehouse'],
            schema=db_profile['schema'],
            role=db_profile['role'])
        conn.check_cursor()
        assert conn.closed is False
        return conn

    @property
    def database(self):
        return self._database
    
    @database.setter
    def database(self, new_db):
        try:
            self.execute("USE DATABASE {};".format(new_db))
            print("Updated Database to", new_db)
            self._database = new_db
        except:
            print("Could Not Change Database")
            print("Current Database:", self._database)
            print("Failed Database:", new_db)


    @property
    def schema(self):
        return self._schema

    @schema.setter
    def schema(self, new_schema):
        try:
            self.execute("USE {}.{};".format(self.database, new_schema))
            print("Updated Schema to", new_schema)
            self._schema = new_schema
        except:
            print("Could Not Change Schema")
            print("Current Schema:", self._schema)
            print("Failed Schema:", new_schema)

    def get_snowflake_cursor(self):
        """Connect environment user to Snowflake for queries.

        :returns: connection cursor.
        :rtype: snowflake.connection.cursor
        """

        print("Connecting to Snowflake...")
        assert not self.user_name is None
        assert not self.pwd is None
        ctx = snowflake.connector.connect(
            user=self.user_name,
            password=self.pwd,
            account=self.account
            )
        cs = ctx.cursor()
        cs.execute("USE DATABASE {}".format(self.database))
        cs.execute("USE WAREHOUSE {}".format(self.warehouse))
        cs.execute("USE {}.{}".format(self.database, self.schema))
        cs.execute("USE ROLE {}".format(self.role))
        self.conn = ctx
        self.cursor = ctx.cursor()
        return cs

    def activate(self):
        """Activate a closed connection."""

        if self.closed:
            print('activate connection.')
            self.check_cursor()

    def check_cursor(self):
        """Check the status of the connection \
            if closed reopen the connect.
        USF Snowflake was set to timeout \
            after 60 minutes of inactivity on a connection.

        :param: None
        :returns: None
        """

        # reconnect if closed
        if self.closed:
            # reconnect to Snowflake
            self.cursor = self.get_snowflake_cursor()
            self.closed = self.cursor.connection.is_closed()
        # try connection
        try:
            self.cursor.execute('SELECT current_version()')
            one = self.cursor.fetchone()
            print('connected to snowflake version:  {}'.format(one[0]))
        except:
            self.cursor = self.get_snowflake_cursor()
            self.closed = self.cursor.connection.is_closed()
        self.timeout = dt.datetime.now()

    def __str__(self):
        snowflack_connector = f'''USF Snowflake Connector:
            User: {self.user_name}
            Account: {self.account}
            Database: {self._database}
            Warehouse: {self.warehouse}
            Schema:  {self._schema}
            Role:  {self.role}'''
        return snowflack_connector

    def __repr__(self):
        return self.__str__()

    def __enter__(self):
        self.cursor = self.get_snowflake_cursor()
        self.closed = self.cursor.connection.is_closed()
        return self

    def __exit__(self, *args):
        if self.conn is not None:
            self.conn.close()
            self.closed = True
            self.cursor = False

    def close(self):
        """Close the Snowflake Connector"""

        if self.conn is not None:
            self.conn.close()
            self.closed = True
            self.cursor = False
            print('Snowflake Connector is Closed')

    def timed_out(self):
        """Mark Cursor closed if time out has passed."""

        time_lapse = dt.datetime.now() - self.timeout
        if time_lapse.seconds > 3540:  # Timeout over 59 minutes
            self.cursor = False
            return True
        else:
            return False

    def execute(self, sql=None, file=None):
        """execute from file or sql code.

        :param sql: sql, default is None.
        :type sql: string
        :param file: system file with sql, default is None.
        :type file: string
        """

        self.timed_out()
        self.timeout = dt.datetime.now()
        if self.cursor == False:
            self.check_cursor()
        # run query
        query = None
        if file is not None:
            assert os.path.exists(file), 'file not found'
            with open(file) as sql_file:
                query = sql_file.read()
    
        if sql is not None:
            query = sql
        
        if query is not None:
            self.cursor.execute(query)
            print('Query Executed.')
        else:
            print('Unable to execute query.')


    def execute_template(self, template_file, args):
        """Substitute values from args into SQL templates.
        
        :param template_file: folder path for file from self.path
        :type template_file: str
        :param args: key-value pairs for template substitution
        :type args: dict
        """

        with open(template_file) as f:
            query = Template(f.read())
            query = query.safe_substitute(args)
        self.execute(query)


    def fetch(self):
        """Return query results as list.
        
        :returns: List of data extracted from query.
        :rtype: [string]
        """

        self.timed_out()
        self.timeout = dt.datetime.now()
        if self.cursor == False:
            self.check_cursor()
        
        assert self.cursor is not False, "first run conn.check_cursor()."
        results = self.cursor.fetchall()
        return results
        
    def fetch_pandas_all(self):
        """Return query results as pandas Dataframe.
        
        :returns: Dataframe of data.
        :rtype: pandas.DataFrame
        """

        self.timed_out()
        self.timeout = dt.datetime.now()
        if self.cursor == False:
            self.check_cursor()
        
        assert self.cursor is not False, "first run conn.check_cursor()."
        results = self.cursor.fetchall()
        query_desc = self.cursor.description
        col_names = [c[0] for c in query_desc]
        df = pd.DataFrame(results, columns=col_names)
        return df

    def table_exists(self, table_name):
        """Check if a Table Exists in the Current Schema.

        :param table_name: Snowflake Table Name.
        :type table_name: str
        """
        
        query = f"""show tables like 
                        '{table_name}' 
                    in SCHEMA
                        {self.database}.{self.schema};"""
        try:
            self.execute(query)
            self.execute("SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));")
            res = self.cursor.fetchall()
            return len(res) > 0
        except AttributeError as e:
            print(e, '\n Use self.check_cursor() to activate snowflake cursor.')
    
    def get_market_list(self, include_acq=True):
        """BI Creators recommendation for querying USF Markets.
        
        :param include_acq: Include the Markets from US Foods Acquisitions.
        :type include_acq: bool
        """
        
        self.activate()
        if include_acq:
            market_code = "'BLD', 'ACQ'"
        else:
            market_code = "'BLD'"

        query = f"""SELECT
                        D.DIV_NBR,
                        D.DIV_NM,
                        D.RGN_NBR,
                        D.RGN_NM,
                        D.AREA_NBR,
                        D.AREA_NM,
                        AM.MARKET_TYPE_CD,
                        MARKET_TYPE_NM
                        FROM GOLD.XDMADM.DIV_CORP AS D
                        INNER JOIN BUSINESS_ANALYTICS.ANALYTICS.VIEW_ACTIVE_MARKETS AS AM
                            ON AM.DIV_NBR = D.DIV_NBR            
                    WHERE AM.MARKET_TYPE_CD IN ({market_code});"""
        self.execute(query)
        df = self.fetch_pandas_all()
        return df

    def upload(self, table, data):
        """Upload string data into table.

        data_example = "('text', 10), ('row2', 11)"
        
        :param table: Name of table, can inclued database.schema.
        :type table: str
        :param data: String of Values to upload.
        :type data: str
        """

        assert type(data)==str, """data format: "('x', 1),\n('y', 2)"""
        assert data[0]=="(", """data rows should start with '('"""
        assert data[-1]==")", """data rows should end with ')'"""
        assert self.table_exists(table)

        query = f"""INSERT INTO {table} values {data} ;"""
        self.execute(query)

    def upload_batches(self, table, packet):
        """Upload parsed_data packets.

        :param table: Name of table, can inclued database.schema.
        :type table: str
        :param packet: List or single string of data.
        :type packet: list(string) or string
        """

        if type(packet)==list:
            # upload multiple
            for p in packet:
                self.upload(table, p)
        else:
            # upload single
            self.upload(table, packet)

    def grant(
            self,
            access="SELECT",
            db="BUSINESS_ANALYTICS",
            schema="_DS_DEV",
            table=None,
            role="INA_DEV_MODELS"):
        """Grant Access for Roles Accross Domains.

        :param access: Specify the type of access to grant.
            ['SELECT', 'all privileges']
        :type access: str
        :param db:  Database name in snowflake, default: BUSINESS_ANALYTICS
        :type db: str
        :param schema:  Schema inside database to grant access to all tables.
        :type schema: str
        :param table:  Specific table to give grant privileges.
        :type table: str
        :param role:  The snowflake user Role to grant access too.
        :type role: str
        """

        assert access in ['SELECT', 'all privileges']
        self.conn.activate()
        if table==None:
            query = f"""grant {access}
                    on all tables
                    in schema {db}.{schema}
                    to role {role};"""
        else:
            query = f"""grant {access}
                    on table {db}.{schema}.{table}
                    to role {role};"""
        self.conn.cursor.execute(query)
        result = self.conn.cursor.fetchone()
        print(result)
