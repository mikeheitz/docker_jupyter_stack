import boto3


class AwsConn:
    """Store Data in S3 Bucket"""

    def __init__(self, bucket_name):
        self.aws_id = None
        self.aws_key = None
        self.bucket_name = bucket_name
        # connect to s3 bucket
        s3 = boto3.resource('s3')
        self.bucket = s3.Bucket(self.bucket_name)

    def upload_object(self, fname, key):
        """Put object into S3 bucket for Item Loyalty.

        :params fname: Path and file name to load.
        :params key: file name to save in S3. \
            Path is set to '/flaskapp/dev_stage_prod'
        """

        with open(fname) as obj:
            self.bucket.put_object(
                Body=obj.read(),
                Bucket=self.bucket_name,
                Key=key,
                ContentType='text/csv',
                ContentEncoding='utf-8'
            )
 
    def download_data(self, key):
        """Get data from S3 for Item Loyalty.

        :params key: filename in s3 bucket.  Path is set to 'dev_stage_prod'
        :returns: Dataframe of csv contents.
        """

        body = self.bucket.Object(key).get()['Body']
        return body

    def delete_object(self, key):
        """Remove file from s3 bucket.

        :param key: path and file name on S3.
        :type key: str
        """

        self.bucket.delete_objects(Delete={
            'Objects': [{'Key': key}], 'Quiet': True})
