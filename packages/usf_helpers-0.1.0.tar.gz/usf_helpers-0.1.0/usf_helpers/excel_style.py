"""Standard USF EXCEL formatting.

Colors:
    primary
    secondary
    secondary    
Excel
"""

import openpyxl as xl
from openpyxl.styles import PatternFill, Border, Side, Alignment, Protection, Font
from openpyxl.chart import BarChart, Series, Reference
from openpyxl.chart.shapes import GraphicalProperties
from openpyxl.chart.text import RichText
from openpyxl.drawing.text import Paragraph, ParagraphProperties, CharacterProperties

# USF Style Guide

# USF Primary Colors
primary = {
    'usf-orange': 'CF4520',
    'usf-green': '5C8727',
    'usf-gold': 'E7A614',
    'usf-black': '1F1F1F',
    'usf-pearl': 'ffffff',
}
# USF Secondary Colors
secondary = {
    'usf-dark_red': '9F2200',
    'usf-dark_green': '3A5E0B',
    'usf-dark_gold': '996D05',
    'usf-light_orange': 'E4673B',
    'usf-light_yellow': 'F3BA16',
    'usf-light_green': '7AA33D',
}
# USF Accent Colors
accent = {
    'usf-red': 'F10000',
    'usf-blue': '005581',
    'usf-dark_grey': '2F2F2F',
    'usf-grey': '4F4F4F',
    'usf-mid_grey': 'B2B2B2',
    'usf-light_grey': 'D7D7D7',
    'usf-soft_grey': 'F2F2F2',
}


# Helper Functions
def load_workbook(filename):
    """Load a workbook from existing file.

    :param filename:  Workbook path with filename.
    :type filename: str
    :return: Workbook Excel Object
    :rtype: openpyxl.Workbook
    """

    return xl.load_workbook(filename)


def get_new_workbook():
    """Create a blank workbook.
    
    :return: Blank Workbook
    :rtype: openpyxl.Workbook
    """

    return xl.Workbook()


def get_color_hex(usf_color):
    """Pass the Color Key to pull hex code from any color style dictionary.
    
    :param usf_color: usf-color
    :type usf_color: str
    :return: hex color code
    :rtype: str
    """

    if usf_color in primary.keys():
        return primary[usf_color]
    elif usf_color in secondary.keys():
        return secondary[usf_color]
    elif usf_color in accent.keys():
        return accent[usf_color]
    else:
        return None


# US FOODS Title
def font_title(color):
    """get USF worksheet style font to apply to cell

    :param color: usf-color pallet option.
    :type color: str
    :return: Page Title font style object
    :rtype: openpyxl.Font
    """

    color_hex = get_color_hex(color)
    font = Font(name='Baskerville Old Face',
                     size=36,
                     bold=True,
                     italic=False,
                     vertAlign=None,
                     underline='single',
                     strike=False,
                     color=color_hex)
    return font


def font_emphasis(color):
    """get USF worksheet style font to apply to cell

    :param color: usf-color pallet option.
    :type color: str
    :return: emphasis font style object
    :rtype: openpyxl.Font
    """

    color_hex = get_color_hex(color)
    font = Font(name='Calibri',
                     size=20,
                     bold=True,
                     italic=False,
                     vertAlign=None,
                     underline='none',
                     strike=False,
                     color=color_hex)
    return font


def font_row_label(color='usf-black'):
    """get USF worksheet style font to apply to cell

    :param color: usf-color pallet option, defaults to 'usf-black'
    :type color: str, optional
    :return: row label font style object
    :rtype: openpyxl.Font
    """

    color_hex = get_color_hex(color)
    font = Font(name='Calibri',
                     size=14,
                     bold=True,
                     italic=False,
                     vertAlign=None,
                     underline='none',
                     strike=False,
                     color=color_hex)
    return font


def font_column_header(color='usf-black'):
    """get USF worksheet style font to apply to cell

    :param color: usf-color pallet option, defaults to 'usf-black'
    :type color: str, optional
    :return: column header font style object
    :rtype: openpyxl.Font
    """

    color_hex = get_color_hex(color)
    font = Font(name='Calibri',
                     size=14,
                     bold=True,
                     italic=False,
                     vertAlign=None,
                     underline='single',
                     strike=False,
                     color=color_hex)
    return font


def font_value(color='usf-black'):
    """Use to get font style for summary values.
    
    :param color: usf-color pallet option, defaults to 'usf-black'
    :type color: str, optional
    :return: row label font style object
    :rtype: openpyxl.Font
    """

    color_hex = get_color_hex(color)
    font = Font(name='Calibri',
                     size=14,
                     bold=False,
                     italic=False,
                     vertAlign=None,
                     underline='none',
                     strike=False,
                     color=color_hex)
    return font


def font_align(align='center', vertical='top'):
    """Adjust the alignment of a cell.
    
    :param align: horizontal alignment, defaults to 'center'
    :type align: str, optional
    :param vertical: vertical alignment, defaults to 'top'
    :type vertical: str, optional
    :return: alignment style to apply to cell.
    :rtype: openpyxl.Alignment
    """

    alignment = Alignment(
        horizontal=align,
        vertical=vertical)
    return alignment


def fill(color='usf-pearl'):
    """Fill a cell with US Foods Color Style.
    
    :param color: usf-color pallet option, defaults to 'usf-pearl'
    :type color: str, optional
    :return: cell fill background PatternFill.
    :rtype: openpyxl.PatternFill
    """

    color_hex = get_color_hex(color)
    fill = PatternFill(fill_type='solid',
                       start_color=color_hex,
                       end_color=color_hex)
    return fill


def border(border_type='bottom', color='usf-black'):
    """Add borders to a cell using simple preset styles.  Or build your own.
    Boarder:
        Border(left=Side(border_style=border_style,
                    color=color),
            right=Side(border_style=border_style,
                    color=color),
            top=Side(border_style=border_style,
                    color=color),
            bottom=Side(border_style=border_style,
                        color=color),
            diagonal=Side(border_style=border_style,
                        color=color),
            diagonal_direction=0,
            outline=Side(border_style=border_style,
                        color=color),
            vertical=Side(border_style=border_style,
                        color=color),
            horizontal=Side(border_style=border_style,
                        color=color))
        border_style: 'dashDot','dashDotDot', 'dashed','dotted',
            'double','hair', 'medium', 'mediumDashDot', 'mediumDashDotDot',
            'mediumDashed', 'slantDashDot', 'thick', 'thin'

    
    :param border_type: 'bottom', 'subtotal', 'total', 'grand_total'
    :param border_type: str
    :param color:  colors(primary, secondary, or accent)                    
    :type color: str
    """

    color_hex = get_color_hex(color)
    if border_type == 'bottom':
        border = Border(
            bottom=Side(border_style='thin', color=color_hex)
        )
    elif border_type == 'subtotal':
        border = Border(
            top=Side(border_style='thin', color=color_hex),
            bottom=Side(border_style='thin', color=color_hex)
        )
    elif border_type == 'total':
        border = Border(
            top=Side(border_style='thin', color=color_hex)
        )
    elif border_type == 'grand_total':
        border = Border(
            top=Side(border_style='thin', color=color_hex),
            bottom=Side(border_style='double', color=color_hex)
        )
    else:
        border = None
    return border


def format_title(worksheet, range, title=None, align='left'):
    """Set multiple elements to Style USF Title on Spreadsheet.
    
    :param worksheet: Sheet to add formating.
    :type worksheet: openpyxl.Workbook.worksheet
    :param range: Cell to format syntax 'A1'.
    :type range: str
    :param title: Text or value to place in cell, defaults to None
    :type title: str, optional
    :param align: horizontal alignment, defaults to 'left'
    :type align: str, optional
    """

    if title is not None:
        worksheet[range] = title
    worksheet[range].font = font_title('usf-green')
    worksheet[range].fill = fill()


def format_emphasis_label(worksheet, range, title=None, align='right'):
    """Emphasis Labels are larger to call user attention as must recognize on page.
    
    :param worksheet: Sheet to add formating.
    :type worksheet: openpyxl.Workbook.worksheet
    :param range: Cell to format syntax 'A1'.
    :type range: str
    :param title: Text or value to place in cell, defaults to None
    :type title: str, optional
    :param align: horizonal alignment, defaults to 'right'
    :type align: str, optional
    """

    if title is not None:
        worksheet[range] = title
    worksheet[range].font = font_emphasis('usf-black')
    worksheet[range].alignment = font_align(align)
    worksheet[range].fill = fill()


def format_emphasis_value(worksheet, range, title=None, align='right'):
    """Emphasis Values highlight important values the users should see on summary.
    
    :param worksheet: Sheet to add formating.
    :type worksheet: openpyxl.Workbook.worksheet
    :param range: Cell to format syntax 'A1'.
    :type range: str
    :param title: Text or value to place in cell, defaults to None
    :type title: str, optional
    :param align: [description], defaults to 'right'
    :type align: str, optional
    """

    if title is not None:
        worksheet[range] = title
    worksheet[range].font = font_emphasis('usf-orange')
    worksheet[range].alignment = font_align(align)
    worksheet[range].fill = fill()


def format_column_header(worksheet, range, title=None, width=None, fill_color='usf-light_orange'):
    """Standard US Foods Column Headers formatting.  
    
    :param worksheet: Sheet to add formating.
    :type worksheet: openpyxl.Workbook.worksheet
    :param range: Cell to format syntax 'A1'.
    :type range: str
    :param title: Text or value to place in cell, defaults to None
    :type title: str, optional
    :param width: Set the column witdth, defaults to None
    :type width: int, optional
    :param fill_color: usf-color pallet option, defaults to 'usf-light-orange'
    :type fill_color: str, optional
    """

    if title is not None:
        if type(range)==tuple:
            worksheet.cell(range[0], range[1], title)
            range = worksheet.cell(range[0],range[1]).coordinate
        else:
            worksheet[range] = title
    if width is not None:
        worksheet.column_dimensions[worksheet[range].column].width = width
    worksheet[range].font = font_column_header()
    worksheet[range].alignment = font_align('center', 'bottom')
    worksheet[range].fill = fill(fill_color)


def format_row_label(worksheet, range, title=None):
    """Standard US Foods Row Label Style.
    
    :param worksheet: Sheet to add formating.
    :type worksheet: openpyxl.Workbook.worksheet
    :param range: Cell to format syntax 'A1'.
    :type range: str
    :param title: Text or value to place in cell, defaults to None
    :type title: str, optional
    """

    if title is not None:
        if type(range)==tuple:
            worksheet.cell(range[0], range[1], title)
            range = worksheet.cell(range[0],range[1]).coordinate
        else:
            worksheet[range] = title
    worksheet[range].font = font_row_label()
    worksheet[range].alignment = font_align('left', 'bottom')
    worksheet[range].fill = fill()


def format_value(worksheet, range, value, align='right', style='Comma [0]', border_type=None):
    """Format Summary values with slight emphasis.
    
    :param worksheet: Sheet to add formating.
    :type worksheet: openpyxl.Workbook.worksheet
    :param range: Cell to format syntax 'A1'.
    :type range: str
    :param value: text or value to place in cell.
    :type value: str
    :param align: horizonal alignment, defaults to 'right'
    :type align: str, optional
    :param style: openpyxl number format styles, defaults to 'Comma [0]'
    :type style: str, optional
    :param border_type: standard board option to add border to cell, defaults to None
    :type border_type: str, optional
    """

    if value is not None:
        worksheet[range] = value
    worksheet[range].font = font_value()
    worksheet[range].style = style
    worksheet[range].fill = fill()
    worksheet[range].alignment = font_align(align)
    if border is not None:
        worksheet[range].border = border(border_type)

# chart
def create_bar_chart(chart_type, chart_title, x_title=None, y_title=None, x_ft_sz=None, y_ft_sz=None):
    """Create USF Style Plot from Data.
    
    :param chart_type:
        options: ['col', 'bar']
    :type chart_type: str
    :param chart_title: Top Chart Description
    :type chart_title: str
    :parm x_title: name of x axis, defaults to None
    :type x_title: str
    :parm y_title: name of y axis, defaults to None
    :type y_title: str
    :parm x_ft_sz: use hundreds for font size 12 = 1200, defaults to None
    :type x_ft_sz: str
    :parm y_ft_sz: use hundreds for font size 12 = 1200, defaults to None
    :type y_ft_sz: str
    :returns:  Chart Object
    :rtype: openpyxl.chart
    """

    usf_chart = BarChart()
    usf_chart.type = chart_type
    usf_chart.title = chart_title
    # y axis title
    if y_title is not None:
        usf_chart.y_axis.title = y_title
        if y_ft_sz is not None:
            cp = CharacterProperties(sz=y_ft_sz)
            usf_chart.y_axis.txPr = RichText(
                p=[Paragraph(
                    pPr=ParagraphProperties(defRPr=cp),
                    endParaRPr=cp)])
    # x axis title
    if x_title is not None:
        usf_chart.x_axis.title = x_title
        if x_ft_sz is not None:
            cp = CharacterProperties(sz=x_ft_sz)
            usf_chart.x_axis.txPr = RichText(
                p=[Paragraph(
                    pPr=ParagraphProperties(defRPr=cp),
                    endParaRPr=cp)])
    return usf_chart


def set_chart_dimensions(usf_chart, height, width):
    """Set the in Worksheet size of the graphic for the chart layout
    
    :param usf_chart: Openpyxl chart object.
    :type usf_chart: openpyxl.chart
    :param height: Height size of the chart.
    :type height: int
    :param width: Width size of the chart.
    :type width: int
    """

    usf_chart.height = height
    usf_chart.width = width


def add_chart_data(usf_chart, data_worksheet, column, first_row, last_row, header=False, color='usf-orange'):
    """Add Data to a chart object.  Process can be done recursively.
    
    :param usf_chart: Openpyxl chart object.
    :type usf_chart: openpyxl.chart
    :param data_worksheet: Worksheet where data is stored to be plotted.
    :type data_worksheet: openpyxl.worksheet
    :param column: Number for the column containing Data values.
    :type column: int
    :param first_row: first row can be header or first data value.
    :type first_row: int
    :param last_row: last row can be header or first data value.
    :type last_row: int
    :param header: Confirm if first row has header, defaults to False
    :type header: bool, optional
    :param color: usf color guild color, defaults to 'usf-orange'
    :type color: str, optional
    """

    data = Reference(
        data_worksheet,
        min_col=column,
        min_row=first_row,
        max_row=last_row)
    if header:
        usf_chart.add_data(data, titles_from_data=True)
    else:
        usf_chart.add_data(data)
    # add color to last series added
    color_hex = get_color_hex(color)
    count_series = len(usf_chart.series)
    series = usf_chart.series[count_series-1]
    props = GraphicalProperties(solidFill=color_hex) 
    series.graphicalProperties = props


def add_chart_categories(usf_chart, data_worksheet, column, first_row, last_row):
    """Add the labels for the axis Categories.
    
    :param usf_chart: Openpyxl chart object.
    :type usf_chart: openpyxl.chart
    :param data_worksheet: Worksheet where data is stored to be plotted.
    :type data_worksheet: openpyxl.worksheet
    :param column: Number for the column containing Data values.
    :type column: int
    :param first_row: first row can be header or first data value.
    :type first_row: int
    :param last_row: last row can be header or first data value.
    :type last_row: int
    """

    cats = Reference(
        data_worksheet,
        min_col=column,
        min_row=first_row,
        max_row=last_row)
    usf_chart.set_categories(cats)


def chart_plot_in_worksheet(worksheet, usf_chart, range):
    """Helper function for placing plot on worksheet at Range loction.
    
    :param worksheet: Sheet on which to place plot.
    :type worksheet: openpyxl.Workbook.worksheet
    :param usf_chart: Openpyxl chart object.
    :type usf_chart: openpyxl.chart
    :param range: Worksheet range style name, i.e. 'A1'.
    :type range: str
    """

    worksheet.add_chart(usf_chart, range)
    

# data
def populate_row_from_list(worksheet, start_cell, data):
    """From Left to Right place ordered list of data into adjacent cells.
    
    :param worksheet: specific worksheet to add the data.
    :type worksheet: openpyxl.worksheet
    :param start_cell: Row and Column to begin.
    :type start_cell: tuple(int, int)
    :param data: List of data to input
    :type data: list[str]
    """

    r = start_cell[0]
    c = start_cell[1]
    for idx, v in enumerate(data):
        worksheet.cell(r, c+idx, v)


def find_last_prod(worksheet, column, first_row):
    """Interatively find the last column Row.
    
    :param worksheet: Excel Worksheet in workbook
    :type worksheet: openpyxl.worksheet
    :param column: Number for the column containing Data values.
    :type column: int
    :param first_row: first row can be header or first data value.
    :type first_row: int
    :return: first blank cell found working down the column
    :rtype: int
    """

    max_row = first_row
    while worksheet.cell(max_row, column).value is not None:
        max_row +=1
    return max_row
