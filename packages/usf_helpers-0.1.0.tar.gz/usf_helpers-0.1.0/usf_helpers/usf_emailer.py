"""US Foods Email Generator

Script Email sending with this Module of USF Helpers.
Call the E-mail object and pass recipients to send numerous e-mails.

Authors:
    Sam Isken
    Steve Griswold
"""

import os
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib


class Emailer:

    def __init__(self, hostname='smtp.usfood.com'):
        """Emailer class holds settings for building a message and sending.

        :param hostname: If on USFoods IT built server the dns is already configured.
            defaults to 'smtp.usfood.com'
        :type hostname: str, optional
        """

        self._hostname = hostname
        self._sender_email = None
        self._receiver_email = None
        self._bcc = None
        self._body = None
        self._text = None
        self._subject = None
        self._attachments = None
    
    @property 
    def host_name(self):
        """Get or set the hostname for the email service."""

        return self._hostname

    @host_name.setter
    def host_name(self, hostname):
        assert '.' in hostname, "hostname pattern required."
        self._hostname = hostname
        print("host set to", self._hostname)

    @property
    def sender_email(self):
        """Get or set the sender for the email."""

        return self._sender_email
        
    @sender_email.setter
    def sender_email(self, email_address):
        assert '@' in email_address, "email address should have @ symbol."
        self._sender_email = email_address
        print("Email sender set to", self._sender_email)
    
    @property
    def receiver_email(self):
        """Get or set the recipient for the email."""

        return self._receiver_email
    
    @receiver_email.setter
    def receiver_email(self, parameter_list):
        if type(parameter_list)==list:
            for address in parameter_list:
                assert '@' in address, f"Missing @ symbol in {address}"
            self._receiver_email = parameter_list
        elif type(parameter_list)==str:
            assert '@' in parameter_list, f"Missing @ symbol in {parameter_list}"
            self._receiver_email = [parameter_list]
            print('Email recipient set to', self._receiver_email)
        else:
            print("Could not update recipients. Must be str or list.")

    @property
    def bcc(self):
        """Get or set the bcc field for the email."""

        return self._bcc
    
    @bcc.setter
    def bcc(self, parameter_list):
        if type(parameter_list)==list:
            for address in parameter_list:
                assert '@' in address, f"Missing @ symbol in {address}"
            self._bcc = parameter_list
        elif type(parameter_list)==str:
            assert '@' in parameter_list, f"Missing @ symbol in {parameter_list}"
            self._bcc = [parameter_list]
        else:
            print("Could not update bcc. Must be str or list.")

    @property
    def body(self):
        """Get or set the body for the email."""

        return self._body

    @body.setter
    def body(self, body_text):
        assert type(body_text)==str, 'Body must be string.'
        self._body = body_text

    @property
    def subject(self):
        """Get or set the subject for the email."""

        return self._subject
    
    @subject.setter
    def subject(self, subject_text):
        assert type(subject_text)==str, 'Subject must be string.'
        self._subject = subject_text

    @property
    def attachments(self):
        """Get, set or delete the attachments for the email."""
        return self._attachments
    
    @attachments.deleter
    def attachments(self):
        self._attachments = None

    @attachments.setter
    def attachments(self, parameter_list):
        if type(parameter_list)==list:
            for attach in parameter_list:
                assert os.path.exists(attach), f"File Not Found: {attach}"
            self._attachments = parameter_list
        elif type(parameter_list)==str:
            assert os.path.exists(parameter_list), f"File Not Found: {parameter_list}"
            self._attachments = parameter_list
        else:
            print("Could not update attachments. Must be str or list.")

    def __str__(self):
        # Convert list of receivers to str.
        if type(self._receiver_email)==list:
            receiver = ',\n'.join(self._receiver_email)
        else:
            receiver = self._receiver_email
        # Convert list of attachments
        if self._attachments is not None:
            if  type(self._attachments)==list:
                attachments = ',\n'.join(self._attachments)
            else:
                attachments = self._attachments
        else:
            attachments = 'None'
        # Compile string
        e_mail = f'''USF Email Generator:
            From: {self._sender_email}
            To: {receiver}
            Bcc: {self._bcc}
            Subject: {self._subject}
            Body:  {self._body}
            Attachments:  {attachments}'''

        return e_mail

    def __repr__(self):
        return self.__str__()

    def _add_attachments(self):
        #TODO: Add functionality for multiple attachments.
        file_name = self._attachments
        assert os.path.exists(file_name)
        part = MIMEBase('application', "octet-stream")
        with open(file_name, "rb") as f:
            contents = f.read()
        part.set_payload(contents)
        encoders.encode_base64(part)
        part.add_header(
            'Content-Disposition',
            'attachment; filename="{}"'.format(file_name)
            )
        return part

    def build_message(self):
        """Build the string version of the e-mail to be sent."""

        message = MIMEMultipart()
        message["From"] = self._sender_email
        message["To"] = ", ".join(self._receiver_email)
        message["Subject"] = self._subject
        if self._bcc is not None:
            message["Bcc"] = ", ".join(self._bcc)
        if self._attachments is not None:
            message.attach(self._add_attachments())
        self._text = message.as_string()

    def _validate_required(self):
        assert self._sender_email is not None, "sender address is required."
        assert self._receiver_email is not None, "receipient address is required."
        assert self._subject is not None, "Subject is required."
        assert self._body is not None, "E-mail Body cannot be blank."
    
    def send_email(self):
        """Validate and build the message to finaly send the e-mail."""

        self._validate_required()
        self.build_message()
        # get email protocols
        smtpObj = smtplib.SMTP(self._hostname)
        smtpObj.connect()
        smtpObj.ehlo()
        # pass data to protocols
        smtpObj.sendmail(
            self._sender_email,
            self._receiver_email,
            self._text)
        smtpObj.quit()
        print('email sent.')
