"""Package connecting to Data Robot."""

import config
import datarobot as dr


def get_sub_version(env, project_name_root, version):
    """Pull all DataRobot Projects if naming convention matches, \
        then update subversion to last model.

    :param env: The current environment of the application.
    :type env: str
    :param project_name_root: The name of your Project \
        before the version, and excluding space before v.
    :type project_name_root: str
    :param version: the config model version set by the product owner.
    :type version: int
    :return: the subversion of the last model created.
    :rtype: int
    """

    projects = dr.Project.list()
    max_subversion = 0
    env = {'_DEV': ' DEV', '_STG': ' STG', '': ''}[env]
    for proj in projects:
        p_name = proj.project_name
        if p_name.split('.')[0] == f'{project_name_root}{env} v{version}' \
           and int(p_name.split('.')[1]) > max_subversion:
                max_subversion = int(p_name.split('.')[1])
    return max_subversion


def _connect_dr():
    """Simplify the connection process for a new user.
    Guiding were things went wrong along the way.

    :raises ValueError: DATAROBOT_API_TOKEN
    :raises ValueError: [DATAROBOT_ENDPOINT]
    :raises EnvironmentError: [DR_CERT] needed on usfwifi
    """

    print('Connecting to DataRobot Client. Please wait...')
    try:
        dr_token = config.config_section_map('DataRobot')[
            'datarobot_api_token']
    except KeyError:
        raise ValueError('Missing local environmental variable: \
            datarobot_api_token')
    try:
        dr_endpoint = config.config_section_map('DataRobot')[
            'datarobot_endpoint']
    except KeyError:
        raise ValueError('Missing local environmental variable: \
            datarobot_endpoint')

    dr_ssl = None
    # Try connecting as if on USFwifi required zscalerCA.pem
    try:
        dr_ssl = config.config_section_map('DataRobot')['dr_cert']
        dr.Client(
            token=dr_token,
            endpoint=dr_endpoint,
            ssl_verify=dr_ssl
            )
        print('Connected to DataRobot API:  Successfully!')
    # Connect without requirements works on non-USFwifi
    except:  # datarobot calls unique errors not recognized by python.
        print(
            'USFwifi requires SSL Cert for DataRobot API. Missing dr_cert:',
            dr_ssl is None,
            '\nTrying conneciton without Zscaler...'
            )
        try:
            dr.Client(
                token=dr_token,
                endpoint=dr_endpoint
                )
            print('Connected to DataRobot API:  Successfully!')
        except:  # datarobot returns unique error codes
            raise EnvironmentError(
                '''Unable to connect to DataRobot API!
                check .config.ini setup:,
                    [DataRobot]
                        datarobot_endpoint='https://app.datarobot.com/api/v2'
                        datarobot_api_token='<token>'
                        dr_cert='/Users/<userid>/.keys/ZscalerRootCA.pem'
                dr_cert is required on USFWifi set up documention at:
                    https://confluence.usfood.com/display/CHEF/How+To+Setup+Local+Environment+Variables
                '''
                )


def find_project(project_name):
    """Returns Data Robot Project Object.

    :param project_name: The project name from your datarobot \
        account manages projects.
    :type project_name: str
    :raises Exception: Multiple projects with the same name.
    :raises Exception: No project Found matching that name.
    :return: Data Robot Project Obeject from datarobot api python package.
    :rtype: datarobot.Project
    """

    projects = dr.Project.list(search_params={'project_name': project_name})
    if len(projects) > 1:
        print(projects)
        raise Exception(
            f'{project_name} returned more than one data robot project:\n'
            '{projects}')
    elif len(projects) == 0:
        raise Exception(f'{project_name} not found in data robot project.')
    else:
        print('Found project.')
        return projects[0]


def find_model_recommended_for_deployment(project):
    """Data Robot Recommends Models within a Project to use for Deployment.  \
        Find the model recommended for deployment.

    :param project: project object from an existing data robot managed project.
    :type project: datarobot.Project
    :raises Exception: Error for model recommended not found.
    :return: Data Robot model object.
    :rtype: datarobot.Model
    """

    print('Looking for Recommended for Deployment Model...')
    # find recommended model
    recos = dr.ModelRecommendation.get_all(project.id)
    for rec in recos:
        if rec.recommendation_type == 'Recommended for Deployment':
            my_model = rec.get_model()
            print(f'Found: {my_model}')
            return my_model
    raise Exception('Unable to locate the Recommended for Deployment Model.')


def request_predictions(project, model, data):
    """Predictions are Jobs which are process by set workers.
    Start the Prediction Job and receive the Job Object \
        to be able to check if the job is complete and retrieve results.

    :param project: project object from an existing data robot managed project.
    :type project: datarobot.Project
    :param model: Data Robot model object.
    :type model: datarobot.Model
    :param data: DataFrame with matching columns as the Model Training set.
    :type data: pandas.DataFrame
    :return: Data Robot Job Object
    :rtype: datarobot.Job
    """

    # send data to predict
    print('''Waiting for the Robots to assemble their armies.
        Any models training will delay this process.''')
    print('Uploading data for predictions...')
    pred_dataset = project.upload_dataset(data)
    print('Robots have spotted the features to predict \
        and are attacking your data.\n \
            Please wait for the battle to end...')
    predict_job = model.request_predictions(pred_dataset.id)
    return predict_job


def get_predictions(predict_job):
    """Since there is not indictor on if a job as done, \
        you may not be able to get predictions if the job is still running.  \
        None return if the job is still running but print status.

    :param predict_job: Data Robot Job Object
    :type predict_job: datarobot.Job
    :return: Model prediction results.
    :rtype: pandas.DataFrame
    """

    res = predict_job.get_result_when_complete()
    return res


def _get_dr_snowflake_driver():
    """Get the jdbc driver which works with snowflake."""

    usf_driver = None
    for driver in dr.DataDriver.list():
        if 'Snowflake JDBC Driver' in driver.canonical_name:
            usf_driver = driver
    if usf_driver is None:
        EnvironmentError('''Missing Snowflake JDBC Driver.
        See DataRobot api instructions for connections.''')
    else:
        return usf_driver


def connect_snowflake():
    """Connect Snowflake DataStore via jdbc to DataRobot.
        SnowflakeBA is for the BUSINESS_ANALYTICS ROLE.

    :return: SnowflakeBA Data Store Object
    :rtype: dr.DataStore
    """

    # Find Exiting Data Store
    for data_store in dr.DataStore.list():
        if data_store.canonical_name == 'SnowflakeBA':
            return data_store

    # Otherwise Create a New Data Store
    usf_driver = _get_dr_snowflake_driver()
    data_store = dr.DataStore.create(
        data_store_type='jdbc',
        canonical_name='SnowflakeBA',
        driver_id=usf_driver.id,
        jdbc_url='jdbc:snowflake://usfoods.snowflakecomputing.com/?'
                 'role=BUSINESS_ANALYTICS&db=business_analytics&'
                 'schema=_DS_DEV&warehouse=USER_ADHOC'
        )
    print('Created DataRobot DataStore:  "SnowflakeBA"')
    return data_store


def setup_data_source(data_store, qry, qry_name, replace_existing=False):
    """Setup DataSource from SQL Query.
    Warning - long, complex queries are not handled well by datarobot.

    :param data_store: DataRobot Data Store Object to pall query.  \
        Relies on the Role, Database, Schema, and Warehouse.
    :type data_store: datarobot.DataStore
    :param qry: SQL string to place in Datarobot to get data.
    :type qry: str
    :param qry_name: Name to place on query in Data Store list.
    :type qry_name: datarobot.DataSource.canonical_name
    :param replace_existing:  Datarobot skips replace, so delete if true.
    :type replace_existing:  bool
    """

    data_source = None
    existing_name = False
    for ds in dr.DataSource.list():
        if ds.canonical_name == qry_name:
            existing_name = True
            if replace_existing:
                ds.delete()
            else:
                data_source = ds

    if existing_name and not replace_existing:
        UserWarning(f'{qry_name} already is a data source in datarobot. \
            If you are sure you want to overwrite set replace_existing=True.')
        return data_source
    else:
        # Create data_source
        params = dr.DataSourceParameters(
            data_store_id=data_store.id,
            query=qry
        )
        data_source = dr.DataSource.create(
            data_source_type='jdbc',
            canonical_name=qry_name,
            params=params
            )
        return data_source


def data_source_upload(project, data_source):
    """Execute query and save data into DataRobot.
    DataRobot does not store Snowflake Credentials.
    Therefore you must pass credentials at every query run.

    :param project: Project which will run predictions on data.
    :type project: datarobot.Project
    :param data_source: data source object.  \
        Can be found by using dr.DataSource.list().
    :type data_source: datarobot.DataSource
    :return: dataset object to pass to predict or create project.
    :rtype: datarobot.dataset
    """

    prediction_dataset = project.upload_dataset_from_data_source(
        data_source_id=data_source.id,
        username=config.config_section_map('Snowflake')['snowflake_user'],
        password=config.config_section_map('Snowflake')['snowflake_password']
    )
    return prediction_dataset


def create_project_from_datasource(data_source, new_project_name):
    """Create a project from jdbc data source object.

    :param data_source: data source object.  \
        Can be found by using dr.DataSource.list().
    :type data_source: datarobot.DataSource
    :param new_project_name: Name to assign the Project in DataRobot.
    :type new_project_name: str
    """

    project = dr.Project.create_from_data_source(
        data_source_id=data_source.id,
        username=config.config_section_map('Snowflake')['snowflake_user'],
        password=config.config_section_map('Snowflake')['snowflake_password'],
        project_name=new_project_name
    )
    return project


def get_model_scores(model):
    roc = model.get_roc_curve('holdout')
    best = max([s['f1_score'] for s in roc.roc_points])
    model_dict = [s for s in roc.roc_points if s['f1_score'] == best][0]
    model_dict['row_count'] = model.training_row_count
    return model_dict


def update_deployed_model(deployment_id, new_model_id):
    """Check replacement and update model on deployment_id.

    :param deployment_id: See DataRobot Deployments Integration for id.
    :type deployment_id: str
    :param new_model_id: DataRobot model id of new model
    :type new_model_id: str
    """

    deployment = dr.Deployment.get(
        deployment_id=deployment_id)
    status, message, checks = deployment.validate_replacement_model(
        new_model_id=new_model_id)
    if status == 'failing':
        print('Failed to deploy new model.')
        print(checks)
        return False
    else:
        deployment.replace_model(new_model_id, 'SCHEDULED_REFRESH')
        print('Model updated successfully.')
        return True
