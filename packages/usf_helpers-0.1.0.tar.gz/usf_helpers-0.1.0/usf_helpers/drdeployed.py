"""
Usage:
    python datarobot-predict.py <input-file.csv>

This example uses the requests library which you can install with:
    pip install requests
We highly recommend that you update SSL certificates with:
    pip install -U urllib3[secure] certifi
"""
import sys
import os
import requests
import config

API_TOKEN = config.config_section_map(
    'DataRobot')['datarobot_api_token']
USERNAME = config.config_section_map(
    'DataRobot')['datarobot_user_name']
DEPLOYMENT_ID = config.config_section_map(
    'DataRobot')['deployment_id']


class DataRobotPredictionError(Exception):
    """Raised if there are issues getting predictions from DataRobot"""


def check_cert(ssl_cert):
    return os.path.exists(ssl_cert)


def make_datarobot_deployment_predictions(data, deployment_id):
    """Make predictions on data provided using DataRobot deployment_id provided.
    See docs for details:
         https://app.datarobot.com/docs/users-guide/deploy/api/new-prediction-api.html

    :param data: Feature1,Feature2
    :type data:  numeric_value,string
    :param deployment_id:  The ID of the deployment to make predictions with.
    :type deployment_id:  str

    :return: schema:
        https://app.datarobot.com/docs/users-guide/deploy/api/new-prediction-api.html#response-schema

    :raises:  DataRobotPredictionError if there are issues getting predictions
    """

    # Set HTTP headers. The charset should match the contents of the file.
    headers = {'Content-Type': 'text/plain; charset=UTF-8',
               'datarobot-key': '92c3c9fc-f573-8b84-c29a-3210ade4cc87'}

    url = 'https://usfoods.orm.datarobot.com/predApi/v1.0/'\
          'deployments/{deployment_id}/'\
          'predictions?passthroughColumns=CUST_NBR'\
          '&passthroughColumns=PROD_NBR'\
          '&passthroughColumns=DIV_NBR'.format(deployment_id=deployment_id)

    # check ssl
    dr_ssl = config.config_section_map('DataRobot')['dr_cert']
    # Make API request for predictions
    if check_cert(dr_ssl):
        predictions_response = requests.post(
            url,
            auth=(USERNAME, API_TOKEN),
            data=data,
            headers=headers,
            verify=dr_ssl)
    else:
        predictions_response = requests.post(
            url, auth=(USERNAME, API_TOKEN), data=data, headers=headers)
    _raise_dataroboterror_for_status(predictions_response)
    # Return a Python dict following the schema in the documentation
    return predictions_response.json()


def _raise_dataroboterror_for_status(response):
    """Raise DataRobotPredictionError if the request fails \
        along with the response returned"""
    try:
        response.raise_for_status()
    except requests.exceptions.HTTPError:
        err_msg = '{code} Error: {msg}'.format(
            code=response.status_code, msg=response.text)
        raise DataRobotPredictionError(err_msg)


def main(filename, deployment_id):
    """
    Return an exit code on script completion or error.
    Codes > 0 are errors to the shell.
    Also useful as a usage demonstration of
    `make_datarobot_deployment_predictions(data, deployment_id)`
    """
    if not filename:
        print(
            'Input file is required argument. '
            'Usage: python datarobot-predict.py <input-file.csv>')
        return 1
    data = open(filename, 'rb').read()
    try:
        predictions = make_datarobot_deployment_predictions(
            data,
            deployment_id)
    except DataRobotPredictionError as exc:
        print(exc)
        return 1
    return predictions


if __name__ == "__main__":
    filename = sys.argv[1]
    sys.exit(main(filename, DEPLOYMENT_ID))
