"""inaconfig.
Encrypt Passwords into US Foods AWS KMS.
Store the CipherText in config.yml for Server access.
Standard Config for Application Configuration.
"""

import yaml
import boto3
import boto3.session
import base64
import os
import socket


def get_environment():
    """Parse the server name to set environment.
    
    :returns: environment type from server name for config.yml
    :rtype: str
    """

    env_dict = {'d': 'dev', 's': 'test', 'p': 'prod'}
    host = socket.gethostname()
    env = env_dict[host[3]]
    return env


# KMS Functions
def encrypt_value(encrypt_this, cmk, aws_region='us-west-2', aws_access_key_id=None, aws_secret_access_key=None):
    """Encrypt Values for I&A Models.

    :param encrypt_this:  Key or Secret to be Encrypted.
    :type encrypt_this: string
    :param cmk:  Customer Management Key for Team to use to save keys.
    :type cmk: string
    :returns: CiphertextBlob encrypted to b64 save to config.yaml
    :rtype: string
    """

    if aws_access_key_id is not None and aws_secret_access_key is not None:
        kms_client = boto3.client(
            'kms',
            aws_region,
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key
            )
    else:
        kms_client = boto3.client('kms', aws_region)
      
    response = kms_client.encrypt(KeyId=cmk, Plaintext=encrypt_this)
    return base64.b64encode(response['CiphertextBlob'])


def decrypt_value(key_value, aws_region='us-west-2', aws_access_key_id=None, aws_secret_access_key=None):
    """Decrypt the CipherTextString via the KMS Client.

    :param key_value: base64 encode key value from Config.yml.
    :type key_value: string
    :param aws_region:  AWS console region for kms.
    :type aws_region: string
    :returns: KMS key dictionary.
    :rtype: dict
    """

    if aws_access_key_id is not None and aws_secret_access_key is not None:
        kms_client = boto3.client(
            'kms',
            aws_region,
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key
            )
    else:
        kms_client = boto3.client('kms', aws_region)

    response = kms_client.decrypt(
        CiphertextBlob=base64.b64decode(key_value))['Plaintext'].decode('UTF-8')
    return response
boto3.client

def load_yaml(cfg_file):
    return yaml.safe_load(open (cfg_file))


class IAConfig:
    """IAConfig

    Example config.yml:
    ```yaml
        default:
            datawarehouse:
            account: 'usfoods'
            role: 'ina_dev_models'
            warehouse: 'USER_ADHOC'
            db: 'DECSCI'
            schema: 'LIFESTAGES'

        dev:
        datawarehouse:
            account: 'usfoods'
            role: 'ina_dev_models'
            warehouse: 'USER_ADHOC'
            db: 'DECSCI_Dev'
            schema: 'LIFESTAGES'

        test:
        datawarehouse:
            account: 'usfoods'
            role: ' ina_qa_models'
            warehouse: 'USER_ADHOC'
            db: 'DECSCI_DEV'
            schema: 'LIFESTAGES_QA'

        prod:
        datawarehouse:
            account: 'usfoods'
            role: 'MYK_BATCH_PROD'
            warehouse: 'USER_ADHOC'
            db: 'DECSCI'
            schema: 'PERSONAL'

        appliction:
        keys:
            inacmk: 2091f548-561d-45f6-bb02-c78cd5b3885a
            uid: AQICAHg0ZGSEPkAcN1bAF58kMTqKWNFXXF09PHXVlzVnZ1XS2gF9gAxLLghuwAQiGY6l50SUAAAAazBpBgkqhkiG9w0BBwagXDBaAgEAMFUGCSqGSIb3DQEHATAeBglghkgBZQMEAS4wEQQMqW0g2gqFcCG83vIcAgEQgCgym9xbRwDzapgoPBYDXZecnOXIPwVZaD+ghy8nKxssPa7YIc4J3Juj
            pwd: AQICAHg0ZGSEPkAcN1bAF58kMTqKWNFXXF09PHXVlzVnZ1XS2gHa/NHeexn7g9n7nLnh+VgGAAAAZjBkBgkqhkiG9w0BBwagVzBVAgEAMFAGCSqGSIb3DQEHATAeBglghkgBZQMEAS4wEQQMtR4scBRt0SiGat5mAgEQgCONLnXPnqH4immKOZ97zT+9jIvzdgS1s8I4+2hwgzNbc74TvQ==
        config:
            frequency: 1
    ```
    """

    def __init__(self, config_file, config_name="default"):
        """Pass Application Config File on Creation.
        
        :param config_file: Path and Yaml filename with application config.
        :type config_file: str
        :param config_name: default, dev, test, prod.
        :type config_name: str
        """

        self.config_file = config_file
        self.config_dict = load_yaml(config_file)
        server_path = "/app/iamodels/config/config.yml"
        if os.path.exists(server_path):
            server_config = load_yaml(server_path)
            self.config_dict['uid'] = server_config['uid']
            self.config_dict['pwd'] = server_config['pwd']
        self.config_name = config_name

    @classmethod
    def get_env_config(cls, config_path):
        cfg = cls(config_file=config_path)
        env = cfg.get('environ')
        print('Config for Environment:', env)
        if env in ['dev', 'test', 'prod']:
            return cls(config_file=config_path, config_name=env)
        else:
            return cls(config_file=config_path)


    def is_present(self, sub_dict, sub_name, key_name):
        """Check the config Dictionary by subdictionary.
        
        :param sub_dict: Full or partioal config yaml dict.
        :type sub_dict: dict
        :param sub_name: First key of config dictionary
            Primary include default, dev, test, prod, and application
        :type sub_name: str
        :param key_name: key of the value to retreive
        :type key_name: str
        :return: Test for key to exist in sub config dict.
        :rtype: bool
        """

        if sub_name in sub_dict and key_name in sub_dict[sub_name]:
            return True
        else:
            return False

    def get(self, key, aws_region='us-west-2'):
        """Get Logic full pulling data from single config setup.
        
        :param key: key for the value to retrieve.
        :type key: str
        :return: Return the value(s) held in the key.
        :rtype: dict or str
        """

        if self.is_present(self.config_dict, self.config_name, key):
            return self.config_dict[self.config_name][key]
        elif self.is_present(self.config_dict['application'], 'keys', key):
            encrypted_key = self.config_dict['application']['keys'][key]
            if self.is_present(self.config_dict['application'], 'config', 'secret'):
                access_key = self.config_dict['application']['config']['access']
                secret = self.config_dict['application']['config']['secret']
                return decrypt_value(encrypted_key, aws_region, access_key, secret)
            else:
                return decrypt_value(encrypted_key, aws_region)
        elif self.is_present(self.config_dict['application'], 'config', key):
            return self.config_dict['application']['config'][key]
        elif key in self.config_dict:
            return self.config_dict[key]
        return None


if __name__ == "__main__":
    cfg = IAConfig("config.yml")
    db_profile = cfg.get('datawarehouse')
    print("datawarehouse Setup:")
    print(db_profile)

    print("Decrypt Snowflake Production ID")
    print(cfg.get("snflk_uid"))
