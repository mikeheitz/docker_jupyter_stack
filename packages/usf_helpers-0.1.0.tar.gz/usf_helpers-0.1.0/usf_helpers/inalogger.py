"""Insights and Analytics Logging Setup.

Based on the US Food IT Solution Application Architecture.
For more information see IAModels Confluence:
https://confluence.usfood.com/display/IAModels/7.0+CloudWatch+App+Logging+Tracker
"""

import os
import sys
from datetime import datetime as dt
import logging
import subprocess


# Package Configuration
formatter = logging.Formatter('%(asctime)s : %(levelname)s : %(name)s : %(message)s')
log_path = '/app/data/logs'


def _get_logger(name, file_name, log_level=None):
    """Get a python logger with Simple settings to write to log files.
        Log Path and Format can be changed in IAlogger.py.
        Path:  USF Std. is 'app/data/logs/ina'
        Format: time : level : name : message
    
    :param name: the Logger Name, If logger exist by name, the app should use same logger.
    :type name: str or __main__
    :param file_name: 'master.log', 'error.log', or 'express.log'
    :type file_name: str
    :param log_level: logging._level ['INFO', 'DEBUG', etc.]
    :type log_level: str or logging._LEVEL
    :return: returns configured logger with file hander and formating.
    :rtype: logging.Logger
    """

    logger = logging.getLogger(name)  
    # set log level
    if log_level is not None:
        logger.setLevel(log_level)
    # link output file
    log_file = f'{log_path}/{file_name}'
    file_handler = logging.FileHandler(log_file)
    # set formation handler
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    return logger


class IALogger:
    """Get I&A Standard Application Logging Configuration.
        Logs INFO and DEBUG application Out Messages.

        Log Path and Format can be changed in IAlogger.py.
            Path:  USF Std. is 'app/data/logs/ina'
            Format: time : level : name : message
        INFO: 'info.log'
        DEBUG: 'debug.log'
        stdout: 'master.log'
        stderr: 'error.log'
    """

    def __init__(self):
        """Log Path and Format can be changed in IAlogger.py.
            Path:  USF Std. is '/app/data/logs'
            Format: time : level : name : message
        """

        assert os.path.exists(log_path), f"Error missing Path: {log_path}\n" \
            "US Foods Application Standard Path: '/app/data/logs'"
        # master
        self.logger_master = _get_logger("MASTER", 'master.log')
        self.logger_master.info(f"APPLICATION INFO ACTIVATED!")
        self.logger_master.debug(f"APPLICATION DEBUG ACTIVATED!")
        
        self.logger_express = _get_logger("EXPRESS", 'express.log', 'INFO')
        self.logger_express.debug("APPLICATION DEBUG ACTIVATED!")
        
        self.logger_error = _get_logger("ERROR", 'error.log', 'DEBUG')
        self.logger_error.debug("APPLICATION DEBUG ACTIVATED!")

    def info(self, msg):
        """Send info to express logger and Master log.
        
        :param msg: Text to be put into the Express Log.
        :type msg: str
        """

        print(f"{dt.now()} : INFO : MASTER : {msg}")
        self.logger_express.info(msg)

    def debug(self, msg):
        """Send info to error logger and Master log.
        
        :param msg: Text to be put into the error Log.
        :type msg: str
        """

        self.logger_error.debug(msg)
        print(f"{dt.now()} : DEBUG : MASTER : {msg}")

    def run(self, command, time_out):
        """Send Shell Command through Python.
            Redirect Standard Errors.
            Path:  USF Std. is 'app/data/logs/ina'
        
        :param command:  Shell Command to Run through subprocess.
        :type command: str
        :param time_out:  seconds
        :type time_out: int

        example:
            ```Python
            with IAlogger.IALogger() as logger:
                logger.run("python3 src/IAlogger.py")
            ```
        """

        completed_process = None
        with open(f'{log_path}/master.log', 'a') as sys.stdout:
            print(f"{dt.now()} : MASTER : APP : APPLICATION Redirected System Out!")
            try:
                completed_process = subprocess.run(
                    command,
                    shell=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    timeout=time_out)
            except subprocess.TimeoutExpired:
                print(f"{dt.now()} : MASTER : APP : inalogger.py subprocess timedout!")
                self.logger_error.debug(f"inalogger.py subprocess timedout!")

        # log subprocess output
        if completed_process is not None:
            # write std outs
            with open(f'{log_path}/express.log', 'ab') as log:
                log.write(completed_process.stdout)
            # write out any errors
            with open(f'{log_path}/error.log', 'ab') as error_log:
                error_log.write(completed_process.stderr)
            # write out master
            with open(f'{log_path}/master.log', 'ab') as master_log:
                master_log.write(completed_process.stdout)
                master_log.write(completed_process.stderr)


if __name__ == ( "__main__"):
    """ use a run.py to test for Error logging.
        
        ```Python
        import os
        from inalogger import IALogger

        if __name__ == ("__main__"):
            logger = IALogger()
            # Use Virtual Environment
            if os.path.exists('../venv/bin/python3'):
                logger.run("../venv/bin/python3 inalogger.py")
            else:
                logger.run("python3 inalogger.py")
        ```
    """

    logger = IALogger()
    logger.info('Test INFO Log')
    print('Test info log')
    logger.debug('Test Debug Logging')
    print('debug log')
    print(Error)  # will throw error, see docstring. 
        