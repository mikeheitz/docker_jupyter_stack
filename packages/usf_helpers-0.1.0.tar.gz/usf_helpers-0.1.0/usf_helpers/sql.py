"""SQL Grummet (iteration synonym)

SQL Automation for SQL scripts.
"""


import os
from usf_helpers import snow
from usf_helpers.snow import SnowflakeConnector
from usf_helpers import config
from string import Template
import re


SNOW_ERROR = snow.snowflake.connector.errors.ProgrammingError


# helper functions
def check_args(sql_template, args):
    """Checks if all keys in args exist in sql_template.

    :param sql_template: resulting string after Template substitution
    :type sql_template: str
    :param args: key-value pairs for template substitution
    :type args: dict
    """

    # More keys than template
    targs = re.findall(r"\$\w*", sql_template)  # Find Params
    keys_targs = [ t.replace('$','') for t in targs]
    # Check for missing args
    missing_keys = [ k for k in args if k not in keys_targs]
    keys = ', '.join(missing_keys)
    assert not missing_keys, f"missing args: {keys}"
    # Check for missing template parameters
    missing_targs = [ k for k in keys_targs if k not in args]
    keys = ', '.join(missing_targs)
    assert set(args) == set(keys_targs), f"missing Template args: {keys}"
    return True


def parse_queries(sql_text):
    return sql_text.split(';')


def multiple_queries(qry):
    assert type(qry)==str, "Query must be string."
    if qry.count(';') > 1:
        return True
    return False


class Grummet(SnowflakeConnector):
    """Automate a Pipeline of SQL to CREATE VIEW or CREATE TABLE by
    folder structure. Project directory structure should include
    the following within the structure, by default:

        $PROJECT_HOME
            |__src
                |__sql
                    |__template
                    |__core
                    |__enhance
                    |__output
                    |__{other endpoint}
    """

    def __init__(self, config_path, sql_path='src/sql'):
        self.config = config.IAConfig.get_env_config(config_path)
        self.env = self.config.get('environ')
        self.get_conn(self.config)
        self.path = sql_path

    def get_conn(self, cfg):
        env = self.env
        aws_region = cfg.get('aws_region')
        if env == 'local':
            assert os.environ['SNOWFLAKE_USER']
            usr = os.environ['SNOWFLAKE_USER']
            assert os.environ['SNOWFLAKE_PASSWORD'] 
            pwd = os.environ['SNOWFLAKE_PASSWORD']
        elif env == 'prod':
            # USF Server use Service Account /app/config/config.yml
            usr_key = cfg.get('uid')
            usr = config.decrypt_value(usr_key, aws_region)
            pwd_key = cfg.get('pwd')
            pwd = config.decrypt_value(pwd_key, aws_region)
        else:
            # Keys must be in config/config.yml
            # these key names are auto decrypted by config.
            usr = cfg.get('snflk_uid', aws_region)
            pwd = cfg.get('snflk_pwd', aws_region)
            
        # set profile by data warehouse
        db_profile = cfg.get('datawarehouse')
        super().__init__(
            user_name=usr,
            pwd=pwd,
            account=db_profile['account'],
            database=db_profile['db'],
            warehouse=db_profile['warehouse'],
            schema=db_profile['schema'],
            role=db_profile['role'])
        self.check_cursor()
        assert self.closed is False
        
    def write_sql_file(self, qry_string, endpoint, filename):
        """Writes qry_string to endpoint/filename

        :param endpoint: folder name with SQL files
        :type endpoint: str
        :param qry_string: query string
        :type qry_string: str
        :param filename: filename
        :type filename: str
        """

        with open(f'{self.path}/{endpoint}/{filename}', 'w') as f:
            f.write(qry_string)

    def convert_template(self, endpoint, args):
        """Writes sql files from src/sql/template to src/sql/{endpoint}.
        Pass an empty string to have files land in src/sql. Also
        substitutes keys in template with values in args.Files must
        be either .sql or .txt filetypes.

        :param endpoint: folder path for file from PROJECT_HOME
        :type endpoint: str
        :param args: key-value pairs for template substitution
        :type args: dict
        """

        template_path = f'{self.path}/template'
        assert os.path.isdir(template_path), f'SQL templates must be in {template_path}.'
        
        file_list = os.listdir(template_path)
        templates = [f for f in file_list if ('.sql' in f) | ('.txt' in f)]
        for sqlfile in sorted(templates):
            with open(f'{template_path}/{sqlfile}') as f:
                query = Template(f.read())
                check_args(query.template, args)
                query = query.safe_substitute(args)
                self.write_sql_file(query, endpoint, sqlfile)
        print(f'All {len(templates)} template(s) processed.')
        
    def run(self, endpoint):
        """Runs all queries, sorted, in directory endpoint. Files must be
        of .sql or .txt filetypes.

        :param endpoint: folder path for file from PROJECT_HOME
        :type endpoint: str
        """

        endpoint_path = f'{self.path}/{endpoint}'
        file_list = os.listdir(endpoint_path)
        sql_files = [f for f in file_list if ('.sql' in f) | ('.txt' in f)]
        for sqlfile in sorted(sql_files):
            try:
                with open(f'{endpoint_path}/{sqlfile}') as f:
                    query = f.read()
                    if multiple_queries(query):
                        queries = parse_queries(query)
                        for q in queries:
                            self.execute(q)
                    else:
                        self.execute(query)  # Run single query
            except SNOW_ERROR as e:
                print(f'!!!!!\nError in SQL file {sqlfile}\n{e}')
