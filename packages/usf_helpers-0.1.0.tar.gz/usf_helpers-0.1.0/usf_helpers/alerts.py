""" I&A Server Alerts
Applications Deployed on Production Server should use Standard Alerts.

Dependancies:
    Monday.com

Application Issues can log to Project/Function Board for bugs.
Manual Config:
    # Notify Team Member process use Monday.com Automate UI Feature
"""

# TODO: Option Method:  Add Mag's E-mail knowledge
# Where possible, make the API general to I&A, not specific to Monday.com
# TODO:  Applying a rate limit

import requests
import os
from usf_helpers import config as iaconfig

CONFIG_PATH = 'config/config.yml'

try:
    print("trying to get monday.com api token from KMS.")
    cfg = iaconfig.IAConfig(CONFIG_PATH)
    monday_token = cfg.get('mondaytoken')
except:
    print("USF Server missing KMS config, trying to find local var.")
    monday_token = os.environ['MONDAY_TOKEN']

class SSLError(Exception):
    """Exception for SSL Cert missing on USF WIFI."""

class BoardError(Exception):
    """Exception for Missing Board ID."""

def _response_to_data(response):
    """Function to convert the json to the result data value.

    :param response: Request response for api call.
    :type response: request.response
    :return: data dictionary from API response.
    :rtype: dict
    """

    results = response.json()
    data = results['data']
    return data


class AlertAgent:

    def __init__(self, app_name=None, board_id=None, ssl_cert=None):
        """AlertAgent can connect to the designated endpoint.
        
        :param app_name: app_name should describe the application.
        :type app_name: str
        :param board_id: board_id should describe the application.
        :type board_id: str
        :param ssl_cert: Path to the ZscalerRootCA.pem file.
            USF-Wifi testing will require ssl_cert for Zscalar, defaults to None
            See: https://confluence.usfood.com/display/CHEF/How+To+Setup+Local+Environment+Variables
        :type ssl_cert: str, optional
        """

        self._url = "https://api.monday.com/v2/"
        self._api_token = monday_token
        self._headers = {
            'Authorization': self._api_token,
            'Content-Type': "application/json"}
        self._ssl_verify = False
        self._ssl_cert = ssl_cert
        self._app_name = app_name
        self.board_id = board_id
        self._group_id = None

    def activate_ssl(self):
        """If SSL Cert is required activate usage of passing cert."""

        self._ssl_verify = True

    def _request(self, query):
        """request passes args to the url in the agent.
        
        :param query: API structure to send queries.
        :type query: dict
        :raises SSLError: Error if SSL requires Cert but cert not provide.
        :return: Api response with dict of keys and values.
        :rtype: dict
        """

        # structure parameters as args
        args = {'method': 'POST',
            'url': self._url,
            'headers': self._headers,
            'params': query}
        # add the verify parameter if ssl cert needed
        if self._ssl_verify:
            args['verify']=self._ssl_cert
        # try passing the args
        try:
            response = requests.request(**args)
        except Exception as e:
            print(e)
            if self._ssl_cert is None:
                print('Missing SSL Cert.')
                raise SSLError("AlertAgent() Missing ssl_cert.")
            else:
                print('SSL Failed\nTry again using Cert')
                args['verify']=self._ssl_cert
                response = requests.request(**args)
                self.activate_ssl()
        return response

    def list_boards(self):
        """See all the Boards available in Monday.com
        
        :return: list of boards in dictionaries with keys: {id, name}
        :rtype: [{'id', 'name'}]
        """

        turn_page = True
        page_number = 1
        boards = []
        while turn_page:
            url_params =  {'query': "{ boards (page:" + str(page_number) + ") {id name} }" }
            response = self._request(url_params)
            data = _response_to_data(response)
            if len(data['boards']) > 0:
                for board in data['boards']:
                    boards.append(board)
                page_number += 1  # Turn Page
            else:
                turn_page = False
        return boards
        
    def get_board_id(self, board_name):
        """Pass a Monday.com Board to retreive the board id to put in config.
        
        :param board_name: Title of the Monday.com Board.
        :type board_name: str
        :raises NameError: Error for Board name not found or multiple with same name.
        :return: The board id for the api object.
        :rtype: str
        """

        boards = self.list_boards()
        ids = [record['id'] for record in boards if record['name'] == board_name ]
        if len(ids) == 1:
            return ids[0]
        else:
            raise NameError("Board Name Not Unique.")

    # Board Methods
    @property
    def board_id(self):
        """Get or set the board id.  Defaults to None when class is called."""

        return self._board_id
    
    @board_id.setter
    def board_id(self, board_id):
        if type(board_id) is not str:
            try:
                self._board_id = str(board_id)
            except ValueError:
                raise ValueError("board_id must be string")
        else:
            self._board_id = board_id

    def _verify_board(self):
        """Raise Error if Board Id is missing.
        
        :raises BoardError: Notificaiton for missing Board Id.
        """

        if self.board_id is None:
            raise BoardError("AlertAgent(): board_id is None.")
 
    @property
    def app_name(self):
        """App Name for the Production Server to know which product has Bug."""

        return self._app_name
    
    @app_name.setter
    def app_name(self, name):
        self._app_name = name
    
    def _verify_app_name(self):
        """Raise Error if App Name is missing.
        
        :raises ValueError: Notification for missing App Name.
        """

        if self._app_name is None:
            raise ValueError("AlertAgent(): app_name is None.")

    def _list_groups(self):
        """For the current board show all the existing groups.

        :return: List of groups id and title.
        :rtype: dict
        """

        self._verify_board()
        # format board id    
        url_params =  {'query': """{
            boards (ids:""" + str(self.board_id) + """) {
                groups {
                    id
                    title
                    }
                }
            }""" }
        response = self._request(url_params)
        data = _response_to_data(response)
        return data['boards'][0]['groups']

    def _get_group_id(self, group_title):
        """Pass the title of a group and get the group id in response.

        :param group_title: Name appearing on the UI for the group.
        :type group_title: str
        :return: id of the group api object.
        :rtype: str
        """

        groups = self._list_groups()
        ids = [ grp['id'] for grp in groups if grp['title'] == group_title]
        if len(ids) == 1:
            return ids[0]
        else:
            raise NameError(f'No group named:  {group_title}')
    
    def _create_bugs_group(self):
        """Create the Bugs Group if it was not found.
        
        :return: Group ID of Bugs Group.
        :rtype: str
        """

        mutation = '''mutation {
            create_group (
                board_id: ''' + self.board_id + ''',
                group_name: "Bugs"
                ) {
                    id
                }
            }'''
        response = self._request({'query': mutation})
        data = _response_to_data(response)
        return data['create_group']['id']

    def _find_bugs_group(self):
        """Find the group in the board for Bugs.
        
        :raises LookupError: Error if too many Bugs Groups on Board.
        :return: Group ID of Bugs Group.
        :rtype: str
        """

        self._verify_board()
        groups = self._list_groups()
        bugs_group = [rec['id'] for rec in groups if rec['title'] == 'Bugs']
        if len(bugs_group) == 1:
            return bugs_group[0]
        elif len(bugs_group) == 0:
            return self._create_bugs_group()
        else:
            raise LookupError('Too Many Groups Named "Bugs".')
    
    def _get_column_id(self, col_name="Work Item Type"):
        """Look up the Column ID for the column 'Work Item Type'.

        :param col_name:  Name of the Custom Column in Monday.com.
        :type col_name: str
        :return: Column id for the monday column object.
        :rtype: str
        """

        query = '''query {
            boards (
                ids: ''' + self.board_id + '''
            ) {
                owner {
                    id
                    }
                columns {
                    id
                    title
                    settings_str
                    }
                }
            }'''
        response = self._request({'query': query})
        columns = response.json()['data']['boards'][0]['columns']
        col_id = [rec['id'] for rec in columns if rec['title'] == col_name]
        if len(col_id) == 1:
            return col_id[0]
        else:
            raise LookupError("AlertAgent(): No Column for Work Item Type.")

    def _update_work_item_type(self, item_id):
        """Update Work Item Type to BUG.
        
        :param item_id: item id code for task created.
        :type item_id: str
        :return: api request response packet.
        :rtype: request.response
        # TODO:  Update Work Item Type "BUG" - Bad API Documentation
        """

        # get the column of Work Item Type
        col_id = self._get_column_id()
        # create mutation query
        mutation = '''mutation {
            change_column_value (
                board_id: ''' + self.board_id + ''',
                item_id: ''' + item_id + ''',
                column_id: "''' + col_id + '''",
                value: "{\"labels\": \"BUG\"}") {
                    id
                }
            }'''
        # send to API url
        response = self._request({'query': mutation})
        return response
    
    def _task_update_message(self, item_id, update_message):
        """Add an Update to the Task for the reason the ticket was created.
        
        :param item_id: task api item id.
        :type item_id: str
        :param update_message: Message to post as update.
        :type update_message: str
        :return: id for the response from the create update mutation. 
        :rtype: str
        # TODO: Replace API User current config is Susan Burns Token.
        """

        mutation = '''mutation {
            create_update (
                item_id: ''' + item_id + ''',
                body: "''' + update_message + '''"
                ) {
                    id
                }
            }'''
        # send to API url
        response = self._request({'query': mutation})
        data = _response_to_data(response)
        return data['create_update']['id']
    
    def _create_bug_task(self, task_name):
        """Create the Task on the current Board.
        
        :param task_name: Title for the Task added to the Board Group.
        :type task_name: str
        :return: Item Id of the new task created.
        :rtype: str
        """

        self._verify_board()
        if self._group_id is None:
            self._group_id = self._find_bugs_group()
        # create mutation query
        mutation = '''mutation {
            create_item (
                board_id: ''' + self.board_id + ''',
                group_id: "''' + self._group_id + '''",
                item_name: "''' + task_name + '''"
                ) {
                    id
                }
            }'''
        # send to API url
        response = self._request({'query': mutation})
        data = _response_to_data(response)
        return data['create_item']['id']

    def warning(self, update_message):
        """Call the Warning Alert.
            task Name = "Warning - Server: {app_name}::{update_message}"

        :param update_message: Message to explain the Warning Issue.
        :type update_message: str
        """

        self._verify_app_name()
        task_name = f"Warning - Server: {self._app_name}"
        item_id = self._create_bug_task(task_name)
        print(f'Task has been created - item_id:  {item_id}')

    def critical(self, update_message):
        """Call the Critical Alert.
            task Name = "Critical - Server: {app_name}::{update_message}"

        :param update_message: Message to explain the Warning Issue.
        :type update_message: str
        """

        self._verify_app_name()
        task_name = f"Critical - Server: {self._app_name}::{update_message}"
        item_id = self._create_bug_task(task_name)
        print(f'Task has been created - item_id:  {item_id}')
