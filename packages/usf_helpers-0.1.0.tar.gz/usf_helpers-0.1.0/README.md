# USF Helper Python Package

---

title: US Foods Helper Functions

authors:

- Steve Griswold

tags:

- data science
- decision science
- aws
- datarobot
- snowflake
- config
- logging

created_at: 2019-08-20

updated_at: 2019-10-03

tldr: Packages for connecting to US Foods Resources.

---

- [Getting Started](docs/v0.0.4/setup/getting_started.md)
  - [Installation](docs/v0.0.4/setup/getting_started.md#installation)
  - [Configuration](docs/v0.0.4/setup/getting_started.md#configuration)
- [IAConfig](docs/v0.0.4/modules/config.md)
- [IALogger](docs/v0.0.4/modules/ialogger.md)
- [USFSnowflakeConnector](docs/v0.0.4/modules/snow.md)
- [ExcelStyle](docs/v0.0.4/modules/excel.md)

## Helper Functions

- [snow](#snow): Connect to Snowflake account from Python.
- [aws](#aws):  Connect to S3 Bucket to upload or download objects.
- [drmodeling](#drmodeling):  Create projects and autopilot models.
- [drdeployed](#drdeployed):  Integration Helper for Deployed DataRobot Model.

## AWS:  S3 Connection

Module:  [usf_helpers/aws.py](usf_helpers/aws.py)

## DataRobot

Module:  [usf_helpers/drmodeling.py](usf_helpers/drmodeling.py)
Module:  [usf_helpers/drdeployed.py](usf_helpers/drdeployed.py)

## Adding to the Helper Package

This USF Package is for shared use.  Please us the versioning methodology defined in dist/CHANGELOG.md.

### Update Setup.py

Change the `name` to end with your userid.  Iterate the `version` according to practices.  Update the `author` and `author_email` to match you.  If your additions requires other packages place those into the `installrequires`.

```Python
setuptools.setup(
    name="usf_helpers_wn61700",
    version="0.0.1",
    author="Steve Griswold",
    author_email="steve.griswold@usfoods.com",
    description="US Foods Helpers for I&A.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://bitbucket.usfood.com/projects/IAD/repos/ds-knowledge/",
    packages=setuptools.find_packages(include=('*.py')),
    install_requires=[
        'boto3==1.9.79',
        'pyyaml==5.1.2',
        'snowflake==0.0.3',
        'snowflake-connector-python==1.8.6'
        ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
```

### Create the Package

Run the setup.py with the following termial command from the same directory.

```!
python3 setup.py sdist bdist_wheel
```

### Install the Package

Usually you are going to put this package in a repository.  The recommended method to do this is to add a directory called `packages` and place the zipped `tar` file in that directory.  Then use a similar command as below.

*Change the install package name based on `user id` and `version`.  

```!
python3 -m pip install packages/usf_helpers_wn61700-0.0.0.tar.gz
```

You can also put this into your requirements.txt

```!
packages/usf_helpers_wn61700-0.0.0.tar.gz
```

### Using the Package

Use the `usf_helpers` package like any other python library.

```Python
import usf_helpers
```

### Mob Reorganizing
